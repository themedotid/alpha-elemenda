<?php wp_footer();?>
</div><!--main-div-->

</body>
</html>
